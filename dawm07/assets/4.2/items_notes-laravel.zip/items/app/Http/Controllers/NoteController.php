<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Item;
use App\Models\Note;

class NoteController extends Controller
{
    public function store(Request $request, Item $item) {
        //return $request->all();  //only to test data has been received.
        //validation:
        $this->validate($request, [
            'content' => 'required|min:10'
        ]);
        $note = new Note;
        $note->content = $request->content;
        $item->notes()->save($note);
        //or alternatively:
        //$item->notes()->create(['content' => $request->content]);
        //or with a method addNote in Item:
        //$item->addNote($note);
        //return \Redirect::to('url');  //with a facade
        //return redirect('url');   //with function
        return back();  //return back.
    }

    public function edit(Note $note) {
        return view('note.form', compact('note'));
    }

    public function update(Request $request, Note $note) {
        $noteNew = Note::find($note->id);
        $noteNew->content = $request->content;
        $noteNew->save();
        return back(); //redirection
     }

}
