 
<?php $__env->startSection('content'); ?>
 
<?php if(empty($items)): ?>
    <p>There are no items!</p>
<?php else: ?>
<ul class="list-group">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
            <a href="/items/<?php echo e($item->id); ?>"><?php echo e($item->title); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>    
<?php endif; ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumne/ws/php/items/resources/views/item/list.blade.php ENDPATH**/ ?>