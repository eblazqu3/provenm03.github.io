<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ItemController;
use App\Http\Controllers\NoteController;

Route::group(['middleware' => ['web']], function () {
    Route::get('/', function () {
        return view('welcome');
    });
});


Route::get('/', function () {
    return view('welcome');
});
 
Route::get('/home', function () {
    return view('welcome');
});
 
Route::get('/items', function () {
    return view('item.index');
});

Route::get('/items/list', [ItemController::class, 'list']);

Route::get('/items/{item}', [ItemController::class, 'find']);

Route::post('/items/{item}/notes', [NoteController::class, 'store']);

Route::get('/notes/{note}/edit', [NoteController::class, 'edit']);

Route::post('/notes/{note}', [NoteController::class, 'update']);