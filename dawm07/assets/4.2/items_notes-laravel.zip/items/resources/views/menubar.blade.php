<nav>
    <ul>
    <li><a href="/home">Home</a></li>
    <li><a href="/items">Items</a></li>
    </ul>
</nav>